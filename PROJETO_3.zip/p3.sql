SELECT numerocandidato, anoinscricao FROM Candidato NATURAL JOIN Inscricao
WHERE numerocandidato > 2
AND anoinscricao > 2018
AND sigladisciplina = 'ing';