(
SELECT cartaocidadaocandidato
FROM Candidato
WHERE numerocandidato > 2
)
INTERSECT
(
SELECT cccandidato
FROM Inscricao
WHERE certidaoinscricao = true
);