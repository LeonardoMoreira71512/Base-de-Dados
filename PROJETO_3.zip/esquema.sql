Create Table Pessoa(
    cartaocidadao INTEGER, 
    PRIMARY KEY (cartaocidadao)     
);

CREATE TABLE JuizDeAtletismo(
    cartaocidadaojuiz INTEGER PRIMARY KEY,
    nome VARCHAR(50),
    FOREIGN KEY(cartaocidadaojuiz) REFERENCES Pessoa(cartaocidadao)
);

CREATE TABLE Candidato(
    cartaocidadaocandidato INTEGER PRIMARY KEY,
    numerocandidato INTEGER,
    FOREIGN KEY (cartaocidadaocandidato) REFERENCES Pessoa(cartaocidadao)
);

CREATE TABLE Leciona(
    sigladadisciplina VARCHAR(5),
    saladisciplina INT,
    ccjuiz INT,
    PRIMARY KEY (sigladadisciplina, saladisciplina, ccjuiz),
    FOREIGN KEY(sigladadisciplina, saladisciplina) REFERENCES Disciplina(sigla,sala),
    FOREIGN KEY(ccjuiz) REFERENCES JuizDeAtletismo(cartaocidadaojuiz)
);

CREATE TABLE Disciplina(
    sigla VARCHAR(5),
    sala INT, 
    PRIMARY KEY (sigla, sala)	
);

CREATE TABLE Inscricao(
    cccandidato INTEGER,
    anoinscricao INTEGER,
    sigladisciplina VARCHAR(5),
    saladisciplina INT,
    preco INT,	
    certidaoinscricao BOOLEAN,
    PRIMARY KEY (cccandidato, anoinscricao, sigladisciplina),
    FOREIGN KEY(cccandidato) REFERENCES Pessoa(cartaocidadao),
    FOREIGN KEY(sigladisciplina,saladisciplina) REFERENCES Disciplina(sigla,sala)
);

CREATE TABLE Realiza(
    cartaocidadaocandidato INT,
    anocandidatura INT,
    estado Varchar(10),
    PRIMARY KEY(cartaocidadaocandidato, anocandidatura),
    FOREIGN KEY(anocandidatura) REFERENCES Candidatura(ano),
    FOREIGN KEY(cartaocidadaocandidato) REFERENCES Pessoa(cartaocidadao)
);

CREATE TABLE Efetua(
    cartaocidadaocandidato INT PRIMARY KEY,
    nivelcertificacaocandidato INT,
    FOREIGN KEY(cartaocidadaocandidato) REFERENCES Pessoa(cartaocidadao)
);

CREATE TABLE Teste(
    cartaocidadaocandidato INT PRIMARY KEY,
    nota INT,
    psicotecnicos INT,
    fisicos INT,
    escrito INT,
    oral INT,
    FOREIGN KEY(cartaocidadaocandidato) REFERENCES Pessoa(cartaocidadao)
);

CREATE TABLE Candidatura(
    nomecandidato VARCHAR(50),
    ano INT,
    PRIMARY KEY (nomecandidato, ano)
);