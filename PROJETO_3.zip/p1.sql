SELECT numerocandidato
FROM Candidato
WHERE cartaocidadaocandidato IN (
                           SELECT cccandidato
                           FROM Inscricao
                           WHERE certidaoinscricao = true
                           AND preco > 20
                         );