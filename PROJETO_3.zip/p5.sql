CREATE VIEW Teste_candidatos (cartaocidadaocandidato, nota) AS
       SELECT cartaocidadaocandidato, nota
       FROM Teste
       WHERE fisicos > 12
       AND escrito > 12; 

SELECT * FROM Teste_candidatos
WHERE nota > 12;

SELECT numerocandidato FROM Candidato NATURAL JOIN Teste_Candidatos;