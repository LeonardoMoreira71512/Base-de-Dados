CREATE VIEW Inscricoes_candidatos (cccandidato, anoinscricao, sigladisciplina) AS
       SELECT cccandidato, anoinscricao, sigladisciplina
       FROM Inscricao
       WHERE saladisciplina < 5;

SELECT * FROM Inscricoes_candidatos
WHERE anoinscricao > 2010 AND anoinscricao < 2020
AND sigladisciplina = 'mat';